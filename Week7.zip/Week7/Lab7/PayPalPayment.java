package Lab7;

public class PayPalPayment extends Payment{
    public PayPalPayment(double amount){
        super(amount);
    }
}
