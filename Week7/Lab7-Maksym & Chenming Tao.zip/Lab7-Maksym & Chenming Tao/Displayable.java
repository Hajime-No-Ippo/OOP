public interface Displayable {

    void displayInfo();
}
