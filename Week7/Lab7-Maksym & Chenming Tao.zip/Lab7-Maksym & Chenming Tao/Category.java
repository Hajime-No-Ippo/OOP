//Chenming Tao 25251621, Maksym Parkhomenko 25259009

public enum Category {

    ELECTRONICS,
    CLOTHING,
    FOOD,
    KITCHENERY,
    DRINKS

}