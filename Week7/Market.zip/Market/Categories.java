package Market;

public enum Categories {
    Electronics,
    Clothing,
    Food,
    Kitchenery,
    Drinks;
}
